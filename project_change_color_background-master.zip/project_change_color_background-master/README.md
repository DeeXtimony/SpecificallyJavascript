# Project_Change_Color_Background
Simple JavaScript Project that changes background each time a button is pressed.
